Setup UI Tree Game Calculator

Unpolished.

Click on Tree-Game-Calc-Design.jar to open the application.
clipboard.txt is used to store the copied material, so you can transfer copied materials.